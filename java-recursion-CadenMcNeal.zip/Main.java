class Main {
  public static void main(String[] args) {
    int num = 2;
    doubling( num );
}
  public static void doubling( int number ){
  if( number < 100 ) {
System.out.println( number );
  number = number * 2;
  doubling( number );
     }}}